(function ($, root, undefined) {

	$(function () {

		'use strict';

		// DOM ready, take it away
		$(".hamburger").click(function(){
			$(".mobile_nav").toggle();
			$(".hamburger").toggleClass("fa-bars");
			$(".hamburger").toggleClass("fa-close");
		});

	});

})(jQuery, this);
