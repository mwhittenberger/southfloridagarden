			<!-- footer -->
			<footer class="footer" role="contentinfo">
				<div class="container">
					<div class="row">
                        <div class="col-sm-12"><img src="/wp-content/uploads/2019/05/white_logo_transparent_background.png"></div>
						<div class="col-sm-12">
							<!-- copyright -->
							<p class="copyright">
								&copy; <?php echo date('Y'); ?> Copyright <?php bloginfo('name'); ?>.
							</p>
							<!-- /copyright -->

						</div>
					</div>
				</div>
			</footer>
			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

	</body>
</html>
